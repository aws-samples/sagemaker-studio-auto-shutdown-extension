version_info = (0, 1, 6)
__version__ = ".".join(map(str, version_info))
